package net.mcreator.starwars.procedures;

import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.starwars.item.CloneTrooperCommanderPyrixArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderBlyArmorItem;
import net.mcreator.starwars.item.CloneTrooperCaptainCryptoArmorItem;
import net.mcreator.starwars.StarWarsModElements;
import net.mcreator.starwars.StarWarsMod;

import java.util.Map;

@StarWarsModElements.ModElement.Tag
public class HelmetOverlayDProcedureProcedure extends StarWarsModElements.ModElement {
	public HelmetOverlayDProcedureProcedure(StarWarsModElements instance) {
		super(instance, 107);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StarWarsMod.LOGGER.warn("Failed to load dependency entity for procedure HelmetOverlayDProcedure!");
			return false;
		}
		Entity entity = (Entity) dependencies.get("entity");
		boolean helmet_overlay_d = false;
		if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderBlyArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay_d = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCaptainCryptoArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay_d = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderPyrixArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay_d = (boolean) (true);
		}
		return (helmet_overlay_d);
	}
}
