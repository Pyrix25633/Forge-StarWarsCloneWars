package net.mcreator.starwars.procedures;

import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.starwars.item.JetpackArmor501stItem;
import net.mcreator.starwars.item.JetpackArmor104thItem;
import net.mcreator.starwars.item.CloneTrooperSergeantArmorItem;
import net.mcreator.starwars.item.CloneTrooperLiutenantArmorItem;
import net.mcreator.starwars.item.CloneTrooperGuardArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderWolffeArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderPyrixArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderGreeArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderFoxArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderCodyArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderBlyArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderAppoArmorItem;
import net.mcreator.starwars.item.CloneTrooperCaptainRexArmorItem;
import net.mcreator.starwars.item.CloneTrooperCaptainCryptoArmorItem;
import net.mcreator.starwars.item.CloneTrooperCaptainArmorItem;
import net.mcreator.starwars.item.CloneTrooperBombArmorItem;
import net.mcreator.starwars.item.CloneTrooperArmorArmorItem;
import net.mcreator.starwars.item.CloneTrooper91stArmorItem;
import net.mcreator.starwars.item.CloneTrooper501stArmorItem;
import net.mcreator.starwars.item.CloneTrooper41stArmorItem;
import net.mcreator.starwars.item.CloneTrooper327thArmorItem;
import net.mcreator.starwars.item.CloneTrooper25633rdArmorItem;
import net.mcreator.starwars.item.CloneTrooper212thArmorItem;
import net.mcreator.starwars.item.CloneTrooper104thArmorItem;
import net.mcreator.starwars.StarWarsModElements;
import net.mcreator.starwars.StarWarsMod;

import java.util.Map;

@StarWarsModElements.ModElement.Tag
public class HelmetOverlayProcedureProcedure extends StarWarsModElements.ModElement {
	public HelmetOverlayProcedureProcedure(StarWarsModElements instance) {
		super(instance, 105);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StarWarsMod.LOGGER.warn("Failed to load dependency entity for procedure HelmetOverlayProcedure!");
			return false;
		}
		Entity entity = (Entity) dependencies.get("entity");
		boolean helmet_overlay = false;
		if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperArmorArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper501stArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperGuardArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCaptainArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperSergeantArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper212thArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper41stArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper91stArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper104thArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper327thArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderCodyArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderWolffeArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderFoxArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderAppoArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderGreeArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperLiutenantArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperBombArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderBlyArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCaptainRexArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper25633rdArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCaptainCryptoArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderPyrixArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(JetpackArmor104thItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(JetpackArmor501stItem.helmet, (int) (1)).getItem())) {
			helmet_overlay = (boolean) (true);
		} else {
			helmet_overlay = (boolean) (false);
		}
		return (helmet_overlay);
	}
}
