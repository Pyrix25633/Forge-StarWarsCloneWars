package net.mcreator.starwars.procedures;

import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.starwars.item.CloneTrooperCommanderFoxArmorItem;
import net.mcreator.starwars.item.CloneTrooperCommanderCodyArmorItem;
import net.mcreator.starwars.item.CloneTrooper91stArmorItem;
import net.mcreator.starwars.StarWarsModElements;
import net.mcreator.starwars.StarWarsMod;

import java.util.Map;

@StarWarsModElements.ModElement.Tag
public class HelmetOverlayBProcedureProcedure extends StarWarsModElements.ModElement {
	public HelmetOverlayBProcedureProcedure(StarWarsModElements instance) {
		super(instance, 108);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StarWarsMod.LOGGER.warn("Failed to load dependency entity for procedure HelmetOverlayBProcedure!");
			return false;
		}
		Entity entity = (Entity) dependencies.get("entity");
		boolean helmet_overlay_b = false;
		if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooper91stArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay_b = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderCodyArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay_b = (boolean) (true);
		} else if ((((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 3))
				: ItemStack.EMPTY).getItem() == new ItemStack(CloneTrooperCommanderFoxArmorItem.helmet, (int) (1)).getItem())) {
			helmet_overlay_b = (boolean) (true);
		}
		return (helmet_overlay_b);
	}
}
