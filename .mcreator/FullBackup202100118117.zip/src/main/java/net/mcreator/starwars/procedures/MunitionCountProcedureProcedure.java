package net.mcreator.starwars.procedures;

import net.minecraftforge.items.CapabilityItemHandler;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.starwars.item.BlasterMunitionsItem;
import net.mcreator.starwars.item.BlasterDc17Item;
import net.mcreator.starwars.item.BlasterDc15sItem;
import net.mcreator.starwars.StarWarsModVariables;
import net.mcreator.starwars.StarWarsModElements;
import net.mcreator.starwars.StarWarsMod;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;

@StarWarsModElements.ModElement.Tag
public class MunitionCountProcedureProcedure extends StarWarsModElements.ModElement {
	public MunitionCountProcedureProcedure(StarWarsModElements instance) {
		super(instance, 129);
	}

	public static boolean executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StarWarsMod.LOGGER.warn("Failed to load dependency entity for procedure MunitionCountProcedure!");
			return false;
		}
		Entity entity = (Entity) dependencies.get("entity");
		double loop_num = 0;
		double item_num = 0;
		loop_num = (double) 0;
		item_num = (double) 0;
		for (int index0 = 0; index0 < (int) (36); index0++) {
			if ((new ItemStack(BlasterMunitionsItem.block, (int) (1)).getItem() == (new Object() {
				public ItemStack getItemStack(int sltid, Entity entity) {
					AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
					entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
						_retval.set(capability.getStackInSlot(sltid).copy());
					});
					return _retval.get();
				}
			}.getItemStack((int) ((loop_num)), entity)).getItem())) {
				item_num = (double) ((item_num) + (((new Object() {
					public ItemStack getItemStack(int sltid, Entity entity) {
						AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
						entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
							_retval.set(capability.getStackInSlot(sltid).copy());
						});
						return _retval.get();
					}
				}.getItemStack((int) ((loop_num)), entity))).getCount()));
			}
			loop_num = (double) ((loop_num) + 1);
		}
		if ((new ItemStack(BlasterMunitionsItem.block, (int) (1))
				.getItem() == ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY).getItem())) {
			item_num = (double) ((item_num)
					+ ((((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY)).getCount()));
		}
		{
			double _setval = (double) Math.round((item_num));
			entity.getCapability(StarWarsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.munition_num = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if (((new ItemStack(BlasterDc15sItem.block, (int) (1))
				.getItem() == ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY).getItem())
				|| (new ItemStack(BlasterDc15sItem.block, (int) (1))
						.getItem() == ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)
								.getItem()))) {
			return (true);
		} else if (((new ItemStack(BlasterDc17Item.block, (int) (1))
				.getItem() == ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemOffhand() : ItemStack.EMPTY).getItem())
				|| (new ItemStack(BlasterDc17Item.block, (int) (1))
						.getItem() == ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)
								.getItem()))) {
			return (true);
		}
		return (false);
	}
}
