package net.mcreator.starwars.entity.renderer;

import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.entity.MobRenderer;

import net.mcreator.starwars.entity.RepublicSpeederEntity;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.mojang.blaze3d.matrix.MatrixStack;

@OnlyIn(Dist.CLIENT)
public class RepublicSpeederRenderer {
	public static class ModelRegisterHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public void registerModels(ModelRegistryEvent event) {
			RenderingRegistry.registerEntityRenderingHandler(RepublicSpeederEntity.entity, renderManager -> {
				return new MobRenderer(renderManager, new Modelspeeder(), 0.9f) {
					@Override
					public ResourceLocation getEntityTexture(Entity entity) {
						return new ResourceLocation("star_wars:textures/speeder.png");
					}
				};
			});
		}
	}

	// Made with Blockbench 3.9.2
	// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
	// Paste this class into your mod and generate all required imports
	public static class Modelspeeder extends EntityModel<Entity> {
		private final ModelRenderer Speeder;
		public Modelspeeder() {
			textureWidth = 128;
			textureHeight = 256;
			Speeder = new ModelRenderer(this);
			Speeder.setRotationPoint(0.0F, 24.0F, 0.0F);
			Speeder.setTextureOffset(68, 128).addBox(-7.0F, -22.0F, 24.0F, 14.0F, 17.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 155).addBox(-8.0F, -28.0F, 8.0F, 16.0F, 26.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 128).addBox(8.0F, -20.0F, 8.0F, 6.0F, 11.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 128).addBox(-14.0F, -20.0F, 8.0F, 6.0F, 11.0F, 16.0F, 0.0F, true);
			Speeder.setTextureOffset(0, 99).addBox(-7.0F, -5.0F, -71.0F, 14.0F, 2.0F, 4.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 105).addBox(-7.0F, -15.0F, -67.0F, 14.0F, 12.0F, 11.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 77).addBox(-10.0F, -13.0F, -56.0F, 3.0F, 6.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 77).addBox(7.0F, -13.0F, -56.0F, 3.0F, 6.0F, 16.0F, 0.0F, true);
			Speeder.setTextureOffset(22, 75).addBox(8.0F, -7.0F, -56.0F, 1.0F, 2.0F, 16.0F, 0.0F, true);
			Speeder.setTextureOffset(22, 75).addBox(-9.0F, -7.0F, -56.0F, 1.0F, 2.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(50, 102).addBox(-7.0F, -16.0F, -56.0F, 14.0F, 10.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(68, 75).addBox(-7.0F, -16.0F, -40.0F, 14.0F, 11.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 35).addBox(-4.0F, -21.0F, -46.0F, 8.0F, 5.0F, 35.0F, 0.0F, false);
			Speeder.setTextureOffset(64, 44).addBox(-8.0F, -16.0F, -24.0F, 16.0F, 10.0F, 16.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 38).addBox(5.0F, -27.0F, -11.0F, 2.0F, 11.0F, 2.0F, 0.0F, true);
			Speeder.setTextureOffset(0, 38).addBox(-7.0F, -27.0F, -11.0F, 2.0F, 11.0F, 2.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 22).addBox(-7.0F, -28.0F, -11.0F, 4.0F, 1.0F, 2.0F, 0.0F, false);
			Speeder.setTextureOffset(0, 22).addBox(3.0F, -28.0F, -11.0F, 4.0F, 1.0F, 2.0F, 0.0F, true);
			Speeder.setTextureOffset(60, 16).addBox(-9.0F, -16.0F, -8.0F, 18.0F, 12.0F, 16.0F, 0.0F, false);
		}

		@Override
		public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue,
				float alpha) {
			Speeder.render(matrixStack, buffer, packedLight, packedOverlay);
		}

		public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
			modelRenderer.rotateAngleX = x;
			modelRenderer.rotateAngleY = y;
			modelRenderer.rotateAngleZ = z;
		}

		public void setRotationAngles(Entity e, float f, float f1, float f2, float f3, float f4) {
		}
	}
}
