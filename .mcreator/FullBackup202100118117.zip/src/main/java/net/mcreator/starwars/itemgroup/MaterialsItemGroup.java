
package net.mcreator.starwars.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.starwars.item.RawTitaniumItem;
import net.mcreator.starwars.StarWarsModElements;

@StarWarsModElements.ModElement.Tag
public class MaterialsItemGroup extends StarWarsModElements.ModElement {
	public MaterialsItemGroup(StarWarsModElements instance) {
		super(instance, 83);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabmaterials") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(RawTitaniumItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
