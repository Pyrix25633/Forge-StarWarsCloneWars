
package net.mcreator.starwars.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.Item;

import net.mcreator.starwars.itemgroup.RepublicItemGroup;
import net.mcreator.starwars.StarWarsModElements;

@StarWarsModElements.ModElement.Tag
public class MusicDiskRepublicItem extends StarWarsModElements.ModElement {
	@ObjectHolder("star_wars:music_disk_republic")
	public static final Item block = null;
	public MusicDiskRepublicItem(StarWarsModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, StarWarsModElements.sounds.get(new ResourceLocation("star_wars:record.republic")),
					new Item.Properties().group(RepublicItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("music_disk_republic");
		}
	}
}
