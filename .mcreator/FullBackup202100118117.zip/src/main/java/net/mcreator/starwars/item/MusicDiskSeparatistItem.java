
package net.mcreator.starwars.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.Item;

import net.mcreator.starwars.itemgroup.SeparatistItemGroup;
import net.mcreator.starwars.StarWarsModElements;

@StarWarsModElements.ModElement.Tag
public class MusicDiskSeparatistItem extends StarWarsModElements.ModElement {
	@ObjectHolder("star_wars:music_disk_separatist")
	public static final Item block = null;
	public MusicDiskSeparatistItem(StarWarsModElements instance) {
		super(instance, 73);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, StarWarsModElements.sounds.get(new ResourceLocation("star_wars:record.separatist")),
					new Item.Properties().group(SeparatistItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("music_disk_separatist");
		}
	}
}
