package net.mcreator.starwars.procedures;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.starwars.item.RepubblicTankShotItem;
import net.mcreator.starwars.entity.RepublicTankEntity;
import net.mcreator.starwars.entity.RepublicSpeederEntity;
import net.mcreator.starwars.StarWarsModElements;
import net.mcreator.starwars.StarWarsMod;

import java.util.Random;
import java.util.Map;

@StarWarsModElements.ModElement.Tag
public class TankShootProcedureProcedure extends StarWarsModElements.ModElement {
	public TankShootProcedureProcedure(StarWarsModElements instance) {
		super(instance, 116);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				StarWarsMod.LOGGER.warn("Failed to load dependency entity for procedure TankShootProcedure!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (((entity.getRidingEntity()) instanceof RepublicTankEntity.CustomEntity)) {
			if (entity instanceof LivingEntity) {
				Entity _ent = entity;
				if (!_ent.world.isRemote()) {
					RepubblicTankShotItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 10, (float) 8, (int) 7);
				}
			}
		}
		if (((entity.getRidingEntity()) instanceof RepublicSpeederEntity.CustomEntity)) {
			if (entity instanceof LivingEntity) {
				Entity _ent = entity;
				if (!_ent.world.isRemote()) {
					RepubblicTankShotItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 10, (float) 5, (int) 3);
				}
			}
		}
	}
}
