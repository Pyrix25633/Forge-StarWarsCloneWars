
package net.mcreator.starwars.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.starwars.item.MusicDiskSeparatistItem;
import net.mcreator.starwars.StarWarsModElements;

@StarWarsModElements.ModElement.Tag
public class SeparatistItemGroup extends StarWarsModElements.ModElement {
	public SeparatistItemGroup(StarWarsModElements instance) {
		super(instance, 113);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabseparatist") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(MusicDiskSeparatistItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}
